//
//  HomeView.swift
//  Holiday Calendar
//
//  Created by Al Housseini, Ahmad on 05.01.25.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    HomeView()
}
