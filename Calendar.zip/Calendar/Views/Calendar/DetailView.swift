//
//  DetailView.swift
//  Calendar
//
//  Created by Al Housseini, Ahmad on 14.01.25.
//

import SwiftUI

struct DetailView: View {
    var image: UIImage?
    var quote: String
    var challenge: Challenge?
    @AppStorage("showInfo") var showInfo = false

    var body: some View {
        ZStack {
            // Background Image
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
            } else {
                Color.gray.edgesIgnoringSafeArea(.all) // Placeholder background
            }

            // Overlay Card
            VStack {
                Spacer() // Push the card to the bottom
                VStack(alignment: .leading, spacing: 10) {
                    // Challenge Name
                    Text(challenge?.text ?? "No Challenge Assigned")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)

                    // Quote or Description
                    Text(quote.isEmpty ? "No quote yet." : quote)
                        .font(.body)
                        .foregroundColor(.white)
                        .lineLimit(nil)
                        .multilineTextAlignment(.leading)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color.black.opacity(0.7)) // Semi-transparent black
                )
                .padding(.horizontal)
                .padding(.bottom, 20) // Spacing from the bottom edge
            }
        }
        .navigationBarBackButtonHidden(true)
//        .toolbar {
//            ToolbarItem(placement: .navigationBarLeading) {
//                Button(action: {
//                    showInfo = false // Back action
//                }) {
//                    Image(systemName: "arrow.left")
//                        .foregroundColor(.white)
//                        .padding()
//                        .background(Color.black.opacity(0.6))
//                        .clipShape(Circle())
//                }
//            }
//        }
    }
}

#Preview {
    DetailView(
        image: UIImage(named: "mediation"), // Replace with an actual asset or nil for testing
        quote: "This is an example quote about the challenge. ahhaha ah ah ah a hah",
        challenge: Challenge(id: 1, text: "Run 5km")
    )
}
