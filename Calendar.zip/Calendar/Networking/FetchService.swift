//
//  FetchService.swift
//  Holiday Calendar
//
//  Created by Al Housseini, Ahmad on 09.01.25.
//

import Foundation


struct FetchService {
    
    private let baseURL = URL(string: "https://breaking-bad-api-six.vercel.app/api")!
    private let idToken = "AIzaSyB-OW1revypMvU5TCfjvVUe0WH4NTdlDwo"
    
  
    
}


